﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading;

namespace Coding_Ex_Process_Director
{
    [TestClass]
    public class _Successful_Login
    {
        [TestMethod]
        public void TestMethod1()
        {   
            
            //Constructor 
            Page_Object.PO_LoginPage Login = new Page_Object.PO_LoginPage();

            //Call methods
            Login.Navigate("https://security.bplogix.net/");
            Login.TypeUser("qa_test");
            Login.TypePass("4#N5Ely5tUu");
            Login.ClickLogBotton();

            //Asserts
            Thread.Sleep(5000);
            Assert.IsTrue(Login.TitleExists());
            

        }
    }
}
