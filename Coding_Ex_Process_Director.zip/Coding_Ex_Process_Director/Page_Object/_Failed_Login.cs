﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading;

namespace Coding_Ex_Process_Director
{
    [TestClass]
    public class _Failed_Login
    {
        [TestMethod]
        public void TestMethod1()
        {
            //Constructor 
            Page_Object.PO_LoginPage Login = new Page_Object.PO_LoginPage();

            //Call methods
            Login.Navigate("https://security.bplogix.net/");
            Login.TypeUser("qa_test");
            Login.TypePass("IncorrectPass");
            Login.ClickLogBotton();

            //Asserts
            Thread.Sleep(1000);
            Assert.IsFalse(Login.TitleExists());


        }
    }
}
