﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;

namespace Coding_Ex_Process_Director.Page_Object
{
    /*Login Page Class*/
    public class PO_LoginPage : IDisposable
    {

        //Selenium Driver
        IWebDriver Driver;

        //Locators
        By User = By.Id("ctl00_ContentPlaceHolder2_UserID");
        By Pass = By.Id("ctl00_ContentPlaceHolder2_Password");
        By boton = By.Id("ctl00_ContentPlaceHolder2_OK_OK");

        
        //Constructor
        public PO_LoginPage()
        {
            this.Driver = Chrome();
        }

         //Initialize Driver

        public IWebDriver Chrome() 
        {
            IWebDriver driver = new ChromeDriver();
            return driver;
        }

        //Methods

        public void Navigate(string url) 
        {
            Driver.Navigate().GoToUrl(url);
        }
        public void TypeUser(string user)
        {
            Driver.FindElement(User).SendKeys(user);
        }

        public void TypePass(string pass)
        {
            Driver.FindElement(Pass).SendKeys(pass);
        }

        public void ClickLogBotton ()
        { 
            Driver.FindElement(boton).Click(); 
        }


        public bool TitleExists() 
        {
            return Driver.Title.Equals("Security");                  
        }

        public void Dispose()
        {
            Driver.Quit();
        }
    }
}
